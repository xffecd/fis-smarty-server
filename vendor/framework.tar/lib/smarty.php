<?php

function getSmarty()
{
    static $smarty = null;
    if (is_null($smarty)) {
        $smarty = new \Smarty();

        //template_dir
        $smarty->setTemplateDir(directoryFormat( __DIR__ . '/../resource/view_file'));
        //config_dir
        $smarty->setConfigDir(directoryFormat(__DIR__ . '/../resource/view_map'));
        //plugins_dir
        $smarty->addPluginsDir(directoryFormat(__DIR__ . '/smarty_plugin'));
        //force compile
        $smarty->force_compile = true;
		
        $smarty->setCompileDir('storage/view_compile');
		$smarty->setCacheDir('storage/view_cache');
        //compile dir
        //left_delimiter, right_delimiter
        $smarty->setLeftDelimiter('{|');
        $smarty->setRightDelimiter('|}');
    }

    return $smarty;
}
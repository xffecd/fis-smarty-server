<?php

function directoryFormat($dir) {
    return str_replace([
        '/',
        '\\'
    ], [
        DIRECTORY_SEPARATOR,
        DIRECTORY_SEPARATOR
    ], $dir);
}

include_once directoryFormat(__DIR__ . '/smarty.php');
include_once directoryFormat(__DIR__ . '/rewrite/Rewrite.php');
//include_once directoryFormat(__DIR__ . '/smarty.php');
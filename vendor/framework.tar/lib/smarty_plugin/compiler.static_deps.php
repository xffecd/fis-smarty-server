<?php
function smarty_compiler_static_deps($arrParams, $smarty)
{
    $relative = str_replace($smarty->_joined_template_dir, '', $smarty->_current_file);
    if (false === $relative) {
        return '';
    }
    $pos = false;
    foreach (['page', 'widget'] as $feature) {
        $text = $feature . DIRECTORY_SEPARATOR;
        $pos = strpos($relative, $text);
        if (false !== $pos) {
            break;
        }

        $text  = DIRECTORY_SEPARATOR . $text;
        $pos = strpos($relative, $text, 1);
        if (false !== $pos) {
            break;
        }
    }
    if (false === $pos) {
        return '';
    }
    
    if (!class_exists('Fis3X', false)) {
        include_once __DIR__ . '/Fis3X.php';
    }

    if (0 === $pos) {
        $resourceId = Fis3X::NAMESPACE_GLOBAL . ":$relative";
    } else {
        $resourceId = substr_replace($relative, ':', $pos-1, 1);
    }

    $classPath = preg_replace(
        '/[\\/\\\\]+/',
        DIRECTORY_SEPARATOR,
        __DIR__ . '/Fis3X.php'
    );

    $code = <<<CODE
<?php
if (!class_exists('Fis3X', false)) {
    include_once '{$classPath}';
}    
\$deps = Fis3X::getDeps('$resourceId', \$_smarty_tpl->smarty);
if (false === \$deps) {
    throw new SmartyException("Failed to get deps for resourceId({$resourceId})");
}
foreach (\$deps as \$dep) {
    Fis3X::load(\$dep, \$_smarty_tpl->smarty);
}
?>
CODE;

    return $code;
}
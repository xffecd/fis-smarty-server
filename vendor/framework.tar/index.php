<?php
include_once __DIR__ . DIRECTORY_SEPARATOR . 'vendor'. DIRECTORY_SEPARATOR . 'autoload.php';
//网站入口
include directoryFormat(__DIR__ . '/public/index.php');
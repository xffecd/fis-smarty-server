## fis3工具,smart视图模板,创建本地测试环境

## 目标
针对当前堡垒机环境进行 最大程度 的兼容

smarty配置

固定环境参数
    
    视图路径: opsLib/View
    左分隔符: {|
    右分隔符: |}
    
可变环境参数

    编译路径: opsLib/Temp/compile
    插件路径: opsLib/SmartyPlugin
    动态配置路径: opsLib/SmartyConf
